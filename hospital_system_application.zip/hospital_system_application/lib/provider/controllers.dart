import 'package:flutter/material.dart';

class Details with ChangeNotifier {
  String _name = "";

  String get name => _name;

  set name(String name) {
    _name = name;
    notifyListeners();
  }

  String _email = "";

  String get email => _email;

  set email(String email) {
    _email = email;
    notifyListeners();
  }

  String _idNumber = "";

  String get idNumber => _idNumber;

  set idNumber(String idNumber) {
    _idNumber = idNumber;
    notifyListeners();
  }

  String _dateOfBirthController = "";

  String get dateOfBirthController => _dateOfBirthController;

  set dateOfBirthController(String dateOfBirthController) {
    _dateOfBirthController = dateOfBirthController;
    notifyListeners();
  }

  String _passwordController = "";

  String get passwordController => _passwordController;

  set passwordController(String passwordController) {
    _passwordController = passwordController;
    notifyListeners();
  }

  String _details = "";

  String get details => _details;

  set details(String details) {
    _details = details;
    notifyListeners();
  }

  String _dateController = "";

  String get dateController => _dateController;

  set dateController(String dateController) {
    _dateController = dateController;
    notifyListeners();
  }

  String _timeController = "";

  String get timeController => _timeController;

  set timeController(String timeController) {
    _timeController = timeController;
    notifyListeners();
  }

  String _reasonController = "";

  String get reasonController => _reasonController;

  set reasonController(String reasonController) {
    _reasonController = reasonController;
    notifyListeners();
  }

  String _hospitalController = "";

  String get hospitalController => _hospitalController;

  set hospitalController(String hospitalController) {
    _hospitalController = hospitalController;
    notifyListeners();
  }

  String _feedbackController = "";

  String get feedbackController => _feedbackController;

  set feedbackController(String feedbackController) {
    _feedbackController = feedbackController;
    notifyListeners();
  }

  String _role = "";

  String get role => _role;

  set role(String role) {
    _role = role;
    notifyListeners();
  }

  String _phoneController = "";

  String get phoneController => _phoneController;

  set phoneController(String phoneController) {
    _phoneController = phoneController;
    notifyListeners();
  }
}
