import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:hospital_system_application/provider/controllers.dart';
import 'package:hospital_system_application/screens/login.dart';

import 'package:provider/provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyD8u0Nwvyb6SMTqLIfqF2Pqc_ub9QSQHeg",
            authDomain: "hospital-system-8af7b.firebaseapp.com",
            projectId: "hospital-system-8af7b",
            storageBucket: "hospital-system-8af7b.appspot.com",
            messagingSenderId: "127911383893",
            appId: "1:127911383893:web:6c02f1280fbb341c1615dc"));
  } else {
    await Firebase.initializeApp();
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => Details(),
        ),
      ],
      builder: (context, child) {
        return MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'Hospital System',
            home: LoginPage());
      },
    );
  }
}
