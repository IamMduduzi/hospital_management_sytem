import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart';
import 'package:hospital_system_application/provider/controllers.dart';
import 'package:hospital_system_application/screens/appointment.dart';
import 'package:hospital_system_application/screens/login.dart';
import 'package:hospital_system_application/screens/profile.dart';
import 'package:hospital_system_application/screens/review.dart';
import 'package:hospital_system_application/screens/vacine.dart';

import 'package:provider/provider.dart';

class MainPageScreen extends StatefulWidget {
  const MainPageScreen({Key? key});

  @override
  State<MainPageScreen> createState() => _MainPageScreenState();
}

class _MainPageScreenState extends State<MainPageScreen> {
  late double width;
  late double height;

  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            "Hospital Management App",
            style: TextStyle(
              color: Colors.white,
            ),
          ),
          backgroundColor: Colors.lightBlue,
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              const DrawerHeader(
                decoration: BoxDecoration(
                  color: Color(0xFF3E69FE),
                  shape: BoxShape.rectangle,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text(
                      "My Profile",
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              ListTile(
                title: const Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Icon(
                      Icons.date_range_rounded,
                      color: Colors.blue,
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    Text(
                      'Appointments',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const AppointmentBooking()));
                },
              ),
              const Divider(
                thickness: 2,
                indent: 40,
              ),
              ListTile(
                title: const Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.person,
                      color: Colors.blue,
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    Text(
                      'Profile',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => ProfileScreen()));
                },
              ),
              const Divider(
                thickness: 2,
                indent: 40,
              ),
              ListTile(
                title: const Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.feedback,
                      color: Colors.blue,
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    Text(
                      'Review',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const ReviewPage()));
                },
              ),
              const Divider(
                thickness: 2,
                indent: 40,
              ),
              ListTile(
                title: const Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.vaccines,
                      color: Colors.blue,
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    Text(
                      'Vaccine',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const VaccinePage()));
                },
              ),
              const Divider(
                thickness: 2,
                indent: 40,
              ),
              ListTile(
                leading: const Icon(
                  Icons.logout,
                  color: Colors.blue,
                ),
                title: const Text('LogOut'),
                onTap: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (_) => LoginPage()));
                },
              ),
            ],
          ),
        ),
        body: SingleChildScrollView(
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                children: <Widget>[
                  Align(
                    alignment: Alignment.topCenter,
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Consumer<Details>(
                        builder: (context, value, child) {
                          return Text(
                            "Welcome ${value.name}",
                            style: const TextStyle(
                              fontSize: 40,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue,
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    "Our MediPlus story",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(7.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: Image.network(
                            "https://media.istockphoto.com/id/1189303662/photo/portrait-of-happy-african-doctor-at-private-clinic.jpg?s=612x612&w=0&k=20&c=P1sA44uF-qI-8Ox5iv4j7dMThSB9trT_QPjYdS13sKo=",
                            fit: BoxFit.contain,
                            height: 180,
                          ),
                        ),
                        const SizedBox(
                          width: 5,
                        ),
                        Expanded(
                          child: Image.network(
                            "https://st3.depositphotos.com/3258807/15729/i/450/depositphotos_157294536-stock-photo-handsome-professional-doctor-looking-at.jpg",
                            fit: BoxFit.contain,
                            height: 180,
                          ),
                        ),
                        Expanded(
                          child: Image.network(
                            "https://thumbs.dreamstime.com/b/planning-training-doctors-people-glass-board-workflow-strategy-hospital-management-internship-medical-students-women-272346261.jpg",
                            fit: BoxFit.contain,
                            height: 180,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  const Text(
                    "Explore our streamlined doctor appointment process.",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      color: Colors.blue,
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  const Text(
                    "By completing our appointment form, our committed Engagement Centre team will swiftly arrange your local doctor visit.",
                    style: TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 15,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    "Simplifying your healthcare experience..",
                    style: TextStyle(
                      fontWeight: FontWeight.w200,
                      fontSize: 15,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Container(
                          child: const Padding(
                            padding: EdgeInsets.all(16.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Icon(
                                  Icons.facebook,
                                  size: 30,
                                  color: Colors.blue,
                                ),
                                SizedBox(
                                  width: 50,
                                ),
                                Icon(
                                  Icons.email,
                                  size: 30,
                                  color: Colors.blue,
                                ),
                                SizedBox(
                                  width: 50,
                                ),
                                Icon(
                                  Icons.facebook,
                                  size: 30,
                                  color: Colors.blue,
                                ),
                                SizedBox(
                                  width: 50,
                                ),
                                Icon(
                                  Icons.email,
                                  size: 30,
                                  color: Colors.blue,
                                ),
                                // Add more social media icons here
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(
                          width: 50,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
