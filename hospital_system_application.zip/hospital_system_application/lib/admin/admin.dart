import 'package:flutter/material.dart';
import 'package:hospital_system_application/admin/appointments.dart';
import 'package:hospital_system_application/admin/doctors.dart';
import 'package:hospital_system_application/admin/profiles.dart';
import 'package:hospital_system_application/admin/reviews.dart';
import 'package:hospital_system_application/admin/vaccine.dart';
import 'package:hospital_system_application/screens/login.dart';

class AdminPage extends StatefulWidget {
  const AdminPage({super.key});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            "Hospital Management App",
            style: TextStyle(
              color: Colors.white,
            ),
          ),
          backgroundColor: Colors.lightBlue,
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              const DrawerHeader(
                decoration: BoxDecoration(
                  color: Color(0xFF3E69FE),
                  shape: BoxShape.rectangle,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text(
                      "Admin Panel",
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              ListTile(
                title: const Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Icon(
                      Icons.date_range_rounded,
                      color: Colors.blue,
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    Text(
                      'Appointments',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const AppointmentsList()));
                },
              ),
              const Divider(
                thickness: 2,
                indent: 40,
              ),
              ListTile(
                title: const Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Icon(
                      Icons.groups_3,
                      color: Colors.blue,
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    Text(
                      'Profiles',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const ProfilesList()));
                },
              ),
              const Divider(
                thickness: 2,
                indent: 40,
              ),
              ListTile(
                title: const Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.medical_information,
                      color: Colors.blue,
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    Text(
                      'Records',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const AppointmentsList()));
                },
              ),
              const Divider(
                thickness: 2,
                indent: 40,
              ),
              ListTile(
                title: const Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.messenger,
                      color: Colors.blue,
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    Text(
                      'Feedback',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const ReviewsList()));
                },
              ),
              const Divider(
                thickness: 2,
                indent: 40,
              ),
              ListTile(
                title: const Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.medical_services,
                      color: Colors.blue,
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    Text(
                      'Doctors',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => DoctorListPage()));
                },
              ),
              const Divider(
                thickness: 2,
                indent: 40,
              ),
              ListTile(
                title: const Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.vaccines,
                      color: Colors.blue,
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    Text(
                      'Vaccine',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const VaccineInfoPage()));
                },
              ),
              const Divider(
                thickness: 2,
                indent: 40,
              ),
              ListTile(
                leading: const Icon(
                  Icons.logout,
                  color: Colors.blue,
                ),
                title: const Text('LogOut'),
                onTap: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (_) => LoginPage()));
                },
              ),
            ],
          ),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'About MediPlus Hospital',
                  style: TextStyle(
                      fontSize: 24.0,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue[900]),
                ),
                const SizedBox(height: 20.0),
                const Text(
                  'MediPlus is a leading healthcare provider dedicated to delivering '
                  'high-quality medical services to our community. We strive to ensure the well-being '
                  'of our patients through personalized care and advanced treatments.',
                  style: TextStyle(fontSize: 18.0, color: Colors.black),
                ),
                const SizedBox(height: 20.0),
                Text(
                  'Services',
                  style: TextStyle(
                      fontSize: 24.0,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue[900]),
                ),
                const SizedBox(height: 10.0),
                const Text(
                  'We offer a comprehensive range of medical services including:'
                  '\n- Cardiology'
                  '\n- Pediatrics'
                  '\n- Orthopedics'
                  '\n- Neurology'
                  '\n- General Surgery'
                  '\n- Dermatology'
                  '\n- and more.',
                  style: TextStyle(fontSize: 18.0, color: Colors.black),
                ),
                const SizedBox(height: 20.0),
                Row(
                  children: <Widget>[
                    const Icon(Icons.phone, size: 30.0, color: Colors.blue),
                    const SizedBox(width: 10.0),
                    Text(
                      'Contact Us',
                      style: TextStyle(
                          fontSize: 24.0,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue[900]),
                    ),
                  ],
                ),
                const SizedBox(height: 10.0),
                const Text(
                  'For inquiries and appointments, please call: MediPlus Hospital 011-0233-267',
                  style: TextStyle(fontSize: 18.0, color: Colors.black),
                ),
                const SizedBox(height: 20.0),
                Row(
                  children: <Widget>[
                    const Icon(Icons.message, size: 30.0, color: Colors.blue),
                    const SizedBox(width: 10.0),
                    Text(
                      'Patient Reviews',
                      style: TextStyle(
                          fontSize: 24.0,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue[900]),
                    ),
                  ],
                ),
                const SizedBox(height: 10.0),
                const Text(
                  'Here are some reviews from our patients:'
                  '\n- "The doctors and staff are very caring and professional."'
                  '\n- "I received excellent treatment and would highly recommend this hospital."'
                  '\n- "The facilities are clean and well-maintained."',
                  style: TextStyle(fontSize: 18.0, color: Colors.black),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
