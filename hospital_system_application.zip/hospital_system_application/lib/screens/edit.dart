import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:hospital_system_application/provider/controllers.dart';

import 'package:hospital_system_application/screens/profile.dart';
//import 'package:hospital_system_application/screens/signup.dart';
import 'package:provider/provider.dart';

class EditPage extends StatefulWidget {
  final String userId;
  @override
  const EditPage({super.key, required this.userId});
  EditPageState createState() => EditPageState();
}

class EditPageState extends State<EditPage> {
  TextEditingController _nameController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _idController = TextEditingController();
  TextEditingController _dateOfBirthController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();
  TextEditingController _phoneController = TextEditingController();
  TextEditingController _passwordConfirmController = TextEditingController();
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  // Add controllers for other fields as needed
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  @override
  void initState() {
    super.initState();
    // Fetch user profile data when the page loads
    fetchUserProfile();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            "Hospital Management App",
            style: TextStyle(
              color: Colors.white,
            ),
          ),
          backgroundColor: Colors.lightBlue,
        ),
        body: Center(
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    const Text(
                      'Update Profile',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 30,
                        color: Colors.blue,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 20),
                    TextFormField(
                      controller: _nameController,
                      decoration: const InputDecoration(
                        labelText: 'Full Name',
                        prefixIcon: Icon(Icons.person, color: Colors.blue),
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Name is required';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: _emailController,
                      decoration: const InputDecoration(
                        labelText: 'Email',
                        prefixIcon: Icon(Icons.email, color: Colors.blue),
                      ),
                      validator: (value) {
                        if (value!.isEmpty || !value.contains('@')) {
                          return 'Please enter a valid email address';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: _idController,
                      decoration: const InputDecoration(
                        labelText: 'Identity Number',
                        prefixIcon:
                            Icon(Icons.calendar_today, color: Colors.blue),
                      ),
                      validator: (value) {
                        if (value!.isEmpty || value.length != 13) {
                          return 'Please enter a valid Identity number';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: _phoneController,
                      decoration: const InputDecoration(
                        labelText: 'Phone Number',
                        prefixIcon: Icon(Icons.phone, color: Colors.blue),
                      ),
                      validator: (value) {
                        if (value!.isEmpty || value.length != 10) {
                          return 'Please enter a valid phone number';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: _dateOfBirthController,
                      decoration: const InputDecoration(
                        labelText: 'Date of Birth',
                        prefixIcon:
                            Icon(Icons.calendar_today, color: Colors.blue),
                      ),
                      validator: (value) {
                        // Add validation logic if needed
                        return null;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: _passwordController,
                      obscureText: true,
                      decoration: const InputDecoration(
                        labelText: 'Password',
                        prefixIcon: Icon(Icons.lock, color: Colors.blue),
                      ),
                      validator: (value) {
                        if (value!.isEmpty || value.length < 8) {
                          return 'Password must be at least 8 characters';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: _passwordConfirmController,
                      obscureText: true,
                      decoration: const InputDecoration(
                        labelText: 'Confirm Password',
                        prefixIcon: Icon(Icons.lock, color: Colors.blue),
                      ),
                      validator: (value) {
                        if (value != _passwordController.text) {
                          return 'Passwords do not match';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: () {
                        //fetchUserProfile();
                        _updateProfile();
                        context.read<Details>().name = _nameController.text;
                        context.read<Details>().email = _emailController.text;
                        context.read<Details>().idNumber = _idController.text;
                        context.read<Details>().dateOfBirthController =
                            _dateOfBirthController.text;
                        context.read<Details>().phoneController =
                            _phoneController.text;
                        context.read<Details>().passwordController =
                            _passwordController.text;
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            backgroundColor: Colors.blue,
                            content: Consumer<Details>(
                              builder: (context, value, child) {
                                return const Text(
                                  "Profile updated successfully",
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.white,
                                  ),
                                );
                              },
                            ),
                          ),
                        );
                        Navigator.pop(context,
                            MaterialPageRoute(builder: (_) => ProfileScreen()));
                      },
                      child: const Text(
                        'Update',
                        style: TextStyle(
                          color: Colors.blue,
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

//fucntion that fetch users information and display it on
  Future<void> fetchUserProfile() async {
    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('profile')
          .doc(widget.userId)
          .get();
      if (userDoc.exists) {
        final userData = userDoc.data() as Map<String, dynamic>;
        setState(() {
          _nameController.text = userData['name'] ?? '';
          _emailController.text = userData['email'] ?? '';
          _idController.text = userData['ID'] ?? '';
          _dateOfBirthController.text = userData['DOB'] ?? '';
          _phoneController.text = userData['Mobile number'] ?? '';
          _passwordController.text = userData['Password'] ?? '';
        });
      }
    } catch (e) {
      print('Error fetching user profile: $e');
    }
  }

//function that update user information
  void _updateProfile() async {
    try {
      if (_formKey.currentState!.validate()) {
        await FirebaseFirestore.instance
            .collection('profile')
            .doc(widget.userId)
            .update({
          'name': _nameController.text,
          'email': _emailController.text,
          'ID': _idController.text,
          'DOB': _dateOfBirthController.text,
          'Mobile number': _phoneController.text,
          'Password': _passwordController.text,
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            backgroundColor: Colors.green,
            content: Text('Profile updated successfully'),
          ),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      print('Error updating profile: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.red,
          content: Text('Failed to update profile: $e'),
        ),
      );
    }
  }
}
