import 'package:flutter/material.dart';

class Appointment {
  final String patientName;
  final String appointmentTime;

  Appointment({
    required this.patientName,
    required this.appointmentTime,
  });
}

class Doctor {
  final String name;
  final String surname;
  final int age;
  final String specialty;
  final List<String> availableTimes;
  List<Appointment> appointments;

  Doctor({
    required this.name,
    required this.surname,
    required this.age,
    required this.specialty,
    required this.availableTimes,
    this.appointments = const [],
  });
}

class DoctorListPage extends StatefulWidget {
  @override
  _DoctorListPageState createState() => _DoctorListPageState();
}

class _DoctorListPageState extends State<DoctorListPage> {
  final List<Doctor> doctors = [
    Doctor(
      name: 'John',
      surname: 'Doe',
      age: 35,
      specialty: 'Cardiologist',
      availableTimes: ['9:00 AM', '11:00 AM', '2:00 PM'],
    ),
    Doctor(
      name: 'Jane',
      surname: 'Smith',
      age: 40,
      specialty: 'Pediatrician',
      availableTimes: ['10:00 AM', '1:00 PM', '3:00 PM'],
    ),
    Doctor(
      name: 'Nontobeko',
      surname: 'Khumalo',
      age: 42,
      specialty: 'Psychiatry',
      availableTimes: ['12:00 PM', '1:00 PM', '3:00 PM'],
    ),
    Doctor(
      name: 'James',
      surname: 'Miller',
      age: 27,
      specialty: 'Surgery',
      availableTimes: ['09:00 AM', '1:00 PM', '3:00 PM'],
    ),
    Doctor(
      name: 'Kate',
      surname: 'Wallace',
      age: 35,
      specialty: 'Neurology',
      availableTimes: ['10:00 AM', '1:00 PM', '3:00 PM'],
    ),
    Doctor(
      name: 'Thabile',
      surname: 'Mthembu',
      age: 29,
      specialty: 'Internal medicine',
      availableTimes: ['10:00 AM', '1:00 PM', '3:00 PM'],
    ),
    Doctor(
      name: 'Nicole',
      surname: 'Wallace',
      age: 51,
      specialty: 'Family medicine',
      availableTimes: ['10:00 AM', '1:00 PM', '3:00 PM'],
    ),
  ];

  void assignAppointment(Doctor doctor, String patientName, String time) {
    setState(() {
      doctor.appointments
          .add(Appointment(patientName: patientName, appointmentTime: time));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Doctors List',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.blue, // App bar color
      ),
      body: ListView.builder(
        itemCount: doctors.length,
        itemBuilder: (context, index) {
          final doctor = doctors[index];
          return Card(
            elevation: 4, // Add elevation to the card for a shadow effect
            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            child: ListTile(
              title: Text(
                '${doctor.name} ${doctor.surname}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.person, color: Colors.blue),
                      const SizedBox(width: 4),
                      Text('Age: ${doctor.age}'),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.medical_services_outlined,
                          color: Colors.blue),
                      const SizedBox(width: 4),
                      Text('Specialty: ${doctor.specialty}'),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.access_time, color: Colors.blue),
                      const SizedBox(width: 4),
                      Text(
                          'Available Times: ${doctor.availableTimes.join(", ")}'),
                    ],
                  ),
                ],
              ),
              onTap: () {
                _showAssignDialog(context, doctor);
              },
            ),
          );
        },
      ),
    );
  }

  void _showAssignDialog(BuildContext context, Doctor doctor) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title:
              Text('Assign Appointment for ${doctor.name} ${doctor.surname}'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Available Times:'),
                ...doctor.availableTimes
                    .map((time) => GestureDetector(
                          onTap: () {
                            assignAppointment(doctor, 'Patient Name',
                                time); // Replace 'Patient Name' with actual patient name
                            Navigator.of(context).pop();
                          },
                          child: Text('- $time'),
                        ))
                    .toList(),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Close', style: TextStyle(color: Colors.blue)),
            ),
          ],
        );
      },
    );
  }
}
