import 'package:flutter/material.dart';

class VaccinePage extends StatelessWidget {
  const VaccinePage({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hospital Management App'),
        backgroundColor: Colors.lightBlue,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                'Welcome to Vaccine Information',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.lightBlue,
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                'Available Vaccine doses',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 20),
            VaccineCard(
              title: 'COVID-19 Vaccine',
              subTitle: 'Information about COVID-19 vaccine',
              image: 'https://via.placeholder.com/150',
              color: Colors.blue,
            ),
            VaccineCard(
              title: 'Influenza Vaccine',
              subTitle: 'Protect yourself from the flu',
              image: 'https://via.placeholder.com/150',
              color: Colors.orange,
            ),
            VaccineCard(
              title: 'Hepatitis B Vaccine',
              subTitle: 'Prevent Hepatitis B infection',
              image: 'https://via.placeholder.com/150', // Placeholder image URL
              color: Colors.green,
            ),
            VaccineCard(
              title: 'Measles Vaccine',
              subTitle: 'Stay safe from measles outbreaks',
              image: 'https://via.placeholder.com/150',
              color: Colors.red,
            ),
          ],
        ),
      ),
    );
  }
}

class VaccineCard extends StatelessWidget {
  final String title;
  final String subTitle;
  final String image;
  final Color color;

  VaccineCard({
    Key? key,
    required this.title,
    required this.subTitle,
    required this.image,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // Add navigation or further action when the card is tapped
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 5,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: color,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(15),
                  bottomLeft: Radius.circular(15),
                ),
              ),
              child: Image.network(
                image,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    subTitle,
                    style: const TextStyle(
                      fontSize: 16,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 20),
          ],
        ),
      ),
    );
  }
}
