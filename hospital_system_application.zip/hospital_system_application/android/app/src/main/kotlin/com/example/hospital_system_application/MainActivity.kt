package com.example.hospital_system_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
