import 'package:flutter/material.dart';

class VaccineInfoPage extends StatelessWidget {
  const VaccineInfoPage({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Vaccine Doses',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20.0,
          ),
        ),
        backgroundColor: Colors.lightBlue,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.all(16.0),
              child: Text(
                'Vaccine Statistics',
                style: TextStyle(
                  fontSize: 24.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                'Total Vaccinations Administered: 10,000',
                style: TextStyle(
                  fontSize: 18.0,
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                'Vaccination Rate: 95%',
                style: TextStyle(
                  fontSize: 18.0,
                ),
              ),
            ),
            const SizedBox(height: 20.0),
            const Padding(
              padding: EdgeInsets.all(16.0),
              child: Text(
                'Vaccine Distribution',
                style: TextStyle(
                  fontSize: 24.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            _buildDistributionCard(
              context,
              'Pfizer-BioNTech',
              '5,000 doses',
              Colors.blue,
            ),
            _buildDistributionCard(
              context,
              'Moderna',
              '3,000 doses',
              Colors.green,
            ),
            _buildDistributionCard(
              context,
              'Johnson & Johnson',
              '2,000 doses',
              Colors.orange,
            ),
            _buildDistributionCard(
              context,
              'AstraZeneca',
              '1,500 doses',
              Colors.red,
            ),
            _buildDistributionCard(
              context,
              'Sinovac',
              '1,200 doses',
              Colors.purple,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDistributionCard(
      BuildContext context, String vaccineName, String doses, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Card(
        elevation: 2.0,
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: color,
            child: Text(
              vaccineName.substring(0, 1),
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          title: Text(vaccineName),
          subtitle: Text('Doses: $doses'),
          onTap: () {
            _showDetails(context, vaccineName, doses);
          },
        ),
      ),
    );
  }

  void _showDetails(BuildContext context, String vaccineName, String doses) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(vaccineName),
          content: Text('Number of doses administered: $doses'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Close', style: TextStyle(color: Colors.blue)),
            ),
          ],
        );
      },
    );
  }
}
