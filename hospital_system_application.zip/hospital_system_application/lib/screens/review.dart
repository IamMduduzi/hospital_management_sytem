import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:hospital_system_application/provider/controllers.dart';
import 'package:provider/provider.dart';

class ReviewPage extends StatefulWidget {
  const ReviewPage({Key? key});

  @override
  _ReviewPageState createState() => _ReviewPageState();
}

class _ReviewPageState extends State<ReviewPage> {
  TextEditingController _hospitalController = TextEditingController();
  TextEditingController _feedbackController = TextEditingController();

  //Submiting user input to the database
  void _submitReview() async {
    // Send the review data to the backend
    try {
      await FirebaseFirestore.instance.collection('reviews').add({
        'Hospital Attended': _hospitalController.text,
        'Review': _feedbackController.text,
      });

      // Show success message or navigate to another screen
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.blue,
          content: Consumer<Details>(
            builder: (context, value, child) {
              return Text(
                "${value.name}, your review has been submitted",
                style: const TextStyle(
                  fontSize: 18,
                  color: Colors.white,
                ),
              );
            },
          ),
        ),
      );
    } catch (e) {
      // Handle errors here
      print(e.toString());
    }

    // Clear text fields after submission
    _hospitalController.clear();
    _feedbackController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlue,
        title: const Text(
          'Hospital Management App',
          style: TextStyle(
            color: Colors.white,
            fontSize: 25,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Text(
                "Reviews",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 40,
                  color: Colors.blue,
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              TextField(
                controller: _hospitalController,
                decoration: InputDecoration(
                  labelText: 'Hospital Attended',
                  labelStyle: const TextStyle(color: Colors.blue),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              const SizedBox(height: 16.0),
              TextField(
                controller: _feedbackController,
                decoration: InputDecoration(
                  labelText: 'Feedback',
                  labelStyle: const TextStyle(color: Colors.blue),
                  hintText: 'Provide your feedback here...',
                  alignLabelWithHint: true,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                maxLines: 4,
              ),
              const SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: _submitReview,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  padding: const EdgeInsets.symmetric(
                    vertical: 12,
                    horizontal: 50,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: const Text(
                  'Submit',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
