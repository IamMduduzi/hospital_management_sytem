import 'package:flutter/material.dart';
import 'package:hospital_system_application/provider/controllers.dart';
import 'package:hospital_system_application/screens/edit.dart';
import 'package:provider/provider.dart';

class ProfileScreen extends StatefulWidget {
  ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlue,
        title: const Text(
          'My Profile',
          style: TextStyle(
            color: Colors.white,
            fontSize: 25,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const Text(
                'Personal Data',
                style: TextStyle(
                  fontSize: 30,
                  color: Colors.blue,
                ),
              ),
              const SizedBox(height: 20),
              _buildProfileItem(
                icon: Icons.person,
                label: 'Full Name:',
                value: Provider.of<Details>(context).name,
              ),
              _buildDivider(),
              _buildProfileItem(
                icon: Icons.email,
                label: 'Email Address:',
                value: Provider.of<Details>(context).email,
              ),
              _buildDivider(),
              _buildProfileItem(
                icon: Icons.calendar_today,
                label: 'Date of Birth:',
                value: Provider.of<Details>(context).dateOfBirthController,
              ),
              _buildDivider(),
              _buildProfileItem(
                icon: Icons.credit_card,
                label: 'Identity Number:',
                value: Provider.of<Details>(context).idNumber,
              ),
              _buildDivider(),
              _buildProfileItem(
                icon: Icons.phone,
                label: 'Mobile number:',
                value: Provider.of<Details>(context).phoneController,
              ),
              _buildDivider(),
              _buildProfileItem(
                icon: Icons.lock,
                label: 'Password:',
                value: Provider.of<Details>(context).passwordController,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const EditPage(
                        userId: '',
                      ),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: const Text(
                  'Edit',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProfileItem(
      {required IconData icon, required String label, required String value}) {
    return Row(
      children: <Widget>[
        Icon(
          icon,
          color: Colors.blue,
          size: 30,
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                label,
                style: const TextStyle(
                  fontSize: 18,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 18,
                  color: Colors.black87,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDivider() {
    return const Divider(
      thickness: 2,
      indent: 40,
    );
  }
}
